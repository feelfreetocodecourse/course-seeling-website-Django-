from django.apps import AppConfig


class FindbestclassConfig(AppConfig):
    name = 'findbestclass'
