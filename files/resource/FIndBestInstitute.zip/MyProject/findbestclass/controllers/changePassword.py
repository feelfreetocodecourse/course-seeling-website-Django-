from django.shortcuts import render
from django.http import HttpResponse
from django.core.exceptions import ObjectDoesNotExist
from findbestclass.models import Student;

def studentChangePassword(request):
	print("CHange changeStudentPassowrd")
	cpassword = request.GET['cpassword'];
	npassword = request.GET['npassword'];
	npassword2 = request.GET['npassword2'];
	id = request.session.get('studentId');
	student = Student.objects.get(id=id);
	if(student.password == cpassword):
		student.password = npassword;
		student.save();
		return HttpResponse("ok")
	else:
		return HttpResponse("Current Passowrd is Wrong !! ")
	return HttpResponse("Current Passowrd is Wrong !! ");
	