# Python code to illustrate Sending mail from  
# your Gmail account

import smtplib 



def sendMail(message , to):
	print('sendmail')
	print(to)
	print(message)
	s = smtplib.SMTP('smtp.gmail.com', 587) 
	s.starttls() 
	s.login("teamnahalo@gmail.com", "nahalo@123"); 
	s.sendmail("teamnahalo@gmail.com", to, message) 
	s.quit() 
	print('sent')


